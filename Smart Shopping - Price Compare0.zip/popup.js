var currentTab;

// Create data store
var tabDataStore = {};

var originUrls = ["http://www.amazon.in",
  "https://www.amazon.in",
  "https://www.flipkart.com"
];

$('#productForm').submit(function (ev) {
  ev.preventDefault(); // to stop the form from submitting
  /* Validations go here */
  let flag = true;

  $("#validationText").empty();
  $("#resultDiv").empty();
  var pn = $('#productName').val();
  if (!$.trim(pn)) {
    $("#validationText").append("<span class='errorText'>Product Name is required!</span>");
    flag = false;
  }
  var pn = $('#productPrice').val();
  if (!$.trim(pn)) {
    $("#validationText").append("<span class='errorText'>Product Price is required!</span>");
    flag = false;
  }
  if (flag === false) {
    return false;
  }
  else {
    callAPI();
  }
});
callAPI = () => {

  var root = 'http://saileshwedseshwari.in/php/sendmail.php';

  $.ajax({
    url: root, success: function (data) {
      $("#resultDiv").append("<span class='errorText'>results = " + data + "</span>");
      onCallSucess();
    }
  });
}

// Save something against that tab's data
function saveData(tab, data) {
  tabDataStore['tab_' + tab.id].urls.push(tab.url);
}
// Load something from tab's data
function getData(tab) {
  tabDataStore['tab_' + tab.id].urls[0];
}

chrome.runtime.onMessage.addListener(function (request, sender) {
  if (request.action == "getSource") {
    afterGettingSource(request.source, sender.tab);
  }
});

function afterGettingSource(data, tab) {
  $("#formDiv").hide();
  $("#noProductErrorWindow").hide();

  let isShoppingSite = false;
  let originUrl = tab.url.match(/^[\w-]+:\/{2,}\[?[\w\.:-]+\]?(?::[0-9]*)?/)[0];
  originUrls.forEach((value) => {
    if (value.startsWith(originUrl)) {
      isShoppingSite = true;
    }
  });
  if (isShoppingSite) {
    var productDetails = {};

    productDetails.domain = originUrl;
    if (tab.url.indexOf('&') !== -1) {
      productDetails.Url = tab.url.substr(0, tab.url.indexOf('&'));
    }
    else {
      productDetails.Url = tab.url;
    }
    // data = data.split("<body")[1].split(">").slice(1).join(">").split("</body>")[0];
    data = data.replace(/<script[^>]+?\/>|<script(.|\s)*?\/script>/gi, '').trim();
    data = $.parseHTML(data);
    if (originUrl.indexOf("amazon") !== -1) {
      productDetails.siteName = "Amazon";
      amazonSource(productDetails, data, tab.id);
    }
    else if (originUrl.indexOf("flipkart") !== -1) {
      productDetails.siteName = "Flipkart";
      flipkartSource(productDetails, data, tab.id);
      console.log("FLIPKART SITE");
    }
  } else {
    disableExtension(tab.id);
  }
}

function flipkartSource(productDetails, data, tabId) {
  let price = 0;

  let productName = $(data).find("._3eAQiD").text().trim();
  let flipkartPriceFormatted = $(data).find("._1vC4OE._37U4_g").text().trim();

  let flipkartRating = ($(data).find("span._2_KrJI").children('div').children('span')[0]).innerText;
  let flipkartReviewCount = $(data).find("span._38sUEc").children('span').text();
  let flipkartReviewUrl = "";
  let flipkartProductImageUrl = $(data).find("div._2SIJjY").children('img').attr('src');

  price = Number(flipkartPriceFormatted.replace(/[^0-9\.]+/g, ""));

  console.log("flipkartPrice  " + flipkartPriceFormatted);
  console.log("price  " + price);
  if (productName && price) {
    productDetails.name = productName;
    productDetails.formattedPrice = flipkartPriceFormatted;
    productDetails.price = price;
    productDetails.rating = flipkartRating;
    productDetails.reviewCount = flipkartReviewCount;
    productDetails.reviewUrl = flipkartReviewUrl;
    productDetails.imageUrl = flipkartProductImageUrl;
    // productName, price, productRating, productReviewCount, productReviewUrl, productImageUrl, tabId
    setValues(productDetails, tabId);
  }
  else {
    showErrorMessageView(tabId);
  }
}

function amazonSource(productDetails, data, tabId) {
  let price = 0;
  let amazonFormatterPrice = "";
  let productName = $(data).find("#productTitle").text().trim();
  let amazonSalePriceS = $(data).find("#priceblock_saleprice").text().trim();
  let amazonPriceS = $(data).find("#priceblock_ourprice").text().trim();
  let amazonDealPriceS = $(data).find("#priceblock_dealprice").text().trim();

  let amazonRating = $(data).find("span#acrPopover").attr('title');
  let amazonReviewCount = $(data).find("span#acrCustomerReviewText").text().trim();
  let amazonReviewUrl = $(data).find("a#acrCustomerReviewLink").attr('href');
  let amazonProductImageUrl = $(data).find("div#imgTagWrapperId").children('img').attr('src');

  //Get Product ID
  // str.substr(0, str.indexOf(' ')); // "72"
  // str.substr(str.indexOf(' ') + 1);
  // /Moto-Plus-4th-Gen-Black/product-reviews/B01DDP7GZK/ref=dpx_acr_txt?showViewpoints=1
  let array1 = amazonReviewUrl.split('/');
  let productId = array1[3];

  //$('.event').children('img').attr('src', '<source here>');
  // .attr("href")

  console.log("amazonRating  ", amazonRating);
  console.log("amazonReviewCount  ", amazonReviewCount);
  console.log("amazonReviewUrl  ", amazonReviewUrl);
  console.log("amazonProductImageUrl  ", amazonProductImageUrl);
  // $('img[src="' + oldSrc + '"]').attr('src', newSrc);

  let amazonPrice = Number(amazonPriceS.replace(/[^0-9\.]+/g, ""));
  let amazonSalePrice = Number(amazonSalePriceS.replace(/[^0-9\.]+/g, ""));
  let amazonDealPrice = Number(amazonDealPriceS.replace(/[^0-9\.]+/g, ""));
  amazonReviewCount = Number(amazonReviewCount.replace(/[^0-9\.]+/g, ""));

  let prices = [];

  if (amazonSalePrice) { prices.push(amazonSalePrice); }
  if (amazonPrice) { prices.push(amazonPrice); }
  if (amazonDealPrice) { prices.push(amazonDealPrice); }

  price = Math.min.apply(Math, prices);
  if (price === amazonPrice) { amazonFormatterPrice = amazonPriceS; }
  else if (price === amazonSalePrice) { amazonFormatterPrice = amazonSalePriceS; }
  else if (price === amazonDealPrice) { amazonFormatterPrice = amazonDealPriceS; }
  if (price == Infinity) {
    price = 0;
  }
  if (productName && price) {
    productDetails.id = productId;
    productDetails.name = productName;
    productDetails.formattedPrice = '\u20B9 ' + amazonFormatterPrice;
    productDetails.price = price;
    productDetails.rating = amazonRating;
    productDetails.reviewCount = amazonReviewCount;
    productDetails.imageUrl = amazonProductImageUrl;
    productDetails.reviewUrl = amazonReviewUrl;
    setValues(productDetails, tabId);
  }
  else {
    showErrorMessageView(tabId);
  }
}

function showErrorMessageView(tabId) {
  $("#formDiv").hide(300);
  $("#noProductErrorWindow").show();
}

function setValues(productDetails, tabId) {
  $("#formDiv").show(300);
  $("#noProductErrorWindow").hide();


  $("#productImage").attr('src', productDetails.imageUrl);   // append("<span class='errorText'>results = " + productName + "</span>");
  $("#productName").text(productDetails.name);
  $("#productPrice").text(productDetails.formattedPrice);
  $("#productRating").text(productDetails.rating);
  $("#productReviewUrl").text(productDetails.reviewCount);

  if (productDetails.siteName === "Amazon") {
    productDetails.Url = "http://www.amazon.in/gp/product/" + productDetails.id;
  }
  if (productDetails.reviewUrl) {
    productDetails.reviewUrl = productDetails.domain + productDetails.reviewUrl;
    $("#productReviewUrl").attr('href', productDetails.reviewUrl);
  }
  else {
    productDetails.reviewUrl = productDetails.Url
    $("#productReviewUrl").attr('href', productDetails.Url);
  }
  console.log("PRODUCT DETAILS === > ", productDetails);
}

onCallSucess = () => {
  // var searchUrl = 'http://www.amazon.in/Imagine-Swhxmirn3-Rubberised-Matte-Xiaomi/dp/B01BPA7RSQ';
  // $.ajax({
  //   url: searchUrl, success: function (data) {


  // data = data.split("<body")[1].split(">").slice(1).join(">").split("</body>")[0];
  // data = data.replace(/<script[^>]+?\/>|<script(.|\s)*?\/script>/gi, '').trim();
  // console.log("DATA =>  ", data);
  // console.log("DATA =>  ", $.parseHTML(data));
  // data = $.parseHTML(data);

  // let productName = $(data).find("#productTitle").text().trim();
  // let salePrice = $(data).find("#priceblock_saleprice").text().trim();
  // $("#resultDiv").append("<span class='errorText'>results = " + productName + "</span>");
  // $("#resultDiv").append("<span class='errorText'>results = " + salePrice + "</span>");

  //     data = $(data).contents().each(function () {
  //       if (this.nodeType === Node.COMMENT_NODE || this.nodeName === "LINK" || this.nodeName === "#comment" || this.nodeName === "META") {
  //         $(this).remove();
  //       }
  //     });

  //   }
  // });
}
/**
 * Get the current URL.
 *
 * @param {function(string)} callback - called when the URL of the current tab
 *   is found.
 */
function getCurrentTabUrl(callback) {
  // Query filter to be passed to chrome.tabs.query - see
  // https://developer.chrome.com/extensions/tabs#method-query
  var queryInfo = {
    active: true,
    currentWindow: true
  };

  chrome.tabs.query(queryInfo, function (tabs) {
    // chrome.tabs.query invokes the callback with a list of tabs that match the
    // query. When the popup is opened, there is certainly a window and at least
    // one tab, so we can safely assume that |tabs| is a non-empty array.
    // A window can only have one active tab at a time, so the array consists of
    // exactly one tab.
    var tab = tabs[0];

    // A tab is a plain object that provides information about the tab.
    // See https://developer.chrome.com/extensions/tabs#type-Tab
    var url = tab.url;

    // tab.url is only available if the "activeTab" permission is declared.
    // If you want to see the URL of other tabs (e.g. after removing active:true
    // from |queryInfo|), then the "tabs" permission is required to see their
    // "url" properties.
    console.assert(typeof url == 'string', 'tab.url should be a string');

    callback(url);
  });
}
function getCurrentTab(callback) {
  var queryInfo = {
    active: true,
    currentWindow: true
  };

  chrome.tabs.query(queryInfo, function (tabs) {
    var tab = tabs[0];

    callback(tab);
  });
}

function getImageUrl(searchTerm, callback, errorCallback) {
  // Google image search - 100 searches per day.
  // https://developers.google.com/image-search/




  // var x = new XMLHttpRequest();
  // x.open('GET', searchUrl);
  // // The Google image search API responds with JSON, so let Chrome parse it.
  // x.responseType = 'json';
  // x.onload = function () {
  //   // Parse and process the response from Google Image Search.
  //   var response = x.response;
  //   if (!response || !response.responseData || !response.responseData.results ||
  //     response.responseData.results.length === 0) {
  //     errorCallback('No response from Google Image search!');
  //     return;
  //   }
  //   var firstResult = response.responseData.results[0];
  //   // Take the thumbnail instead of the full image to get an approximately
  //   // consistent image size.
  //   var imageUrl = firstResult.tbUrl;
  //   var width = parseInt(firstResult.tbWidth);
  //   var height = parseInt(firstResult.tbHeight);
  //   console.assert(
  //     typeof imageUrl == 'string' && !isNaN(width) && !isNaN(height),
  //     'Unexpected respose from the Google Image Search API!');
  //   callback(imageUrl, width, height);
  // };
  // x.onerror = function () {
  //   errorCallback('Network error.');
  // };
  // x.send();
}

function renderStatus(statusText) {
  // document.getElementById('status').textContent = statusText;
}

document.addEventListener('DOMContentLoaded', function () {


  // var message = document.querySelector('#resultDiv');

  // chrome.tabs.executeScript(null, {
  //   file: "getPagesSource.js"
  // }, function () {
  //   // If you try and inject into an extensions page or the webstore/NTP you'll get an error
  //   if (chrome.runtime.lastError) {
  //     message.innerText = 'There was an error injecting script : \n' + chrome.runtime.lastError.message;
  //   }
  // });
  // getCurrentTabUrl(function (url) {
  //   // Put the image URL in Google search.
  //   renderStatus('Performing the search for ' + url);

  //   getImageUrl(url, function (imageUrl, width, height) {

  //     renderStatus('Search term: ' + url + '\n' +
  //       'Google image search result: ' + imageUrl);
  //     var imageResult = document.getElementById('image-result');
  //     // Explicitly set the width/height to minimize the number of reflows. For
  //     // a single image, this does not matter, but if you're going to embed
  //     // multiple external images in your page, then the absence of width/height
  //     // attributes causes the popup to resize multiple times.
  //     imageResult.width = width;
  //     imageResult.height = height;
  //     imageResult.src = imageUrl;
  //     imageResult.hidden = false;

  //   }, function (errorMessage) {
  //     renderStatus('Cannot display image. ' + errorMessage);
  //   });
  // });
});


function getSourceHtml() {
  var message = document.querySelector('#resultDiv');

  chrome.tabs.executeScript(null, {
    file: "getPagesSource.js"
  }, function () {
    // If you try and inject into an extensions page or the webstore/NTP you'll get an error
    if (chrome.runtime.lastError) {
      // message.innerText = 'There was an error injecting script : \n' + chrome.runtime.lastError.message;
    }
  });
}

function onWindowLoad() {

  var message = document.querySelector('#resultDiv');

  chrome.tabs.executeScript(null, {
    file: "getPagesSource.js"
  }, function () {
    // If you try and inject into an extensions page or the webstore/NTP you'll get an error
    if (chrome.runtime.lastError) {
      // message.innerText = 'There was an error injecting script : \n' + chrome.runtime.lastError.message;
    }
  });

}

window.onload = onWindowLoad;