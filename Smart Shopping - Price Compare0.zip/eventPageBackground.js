var badgeTextData = {};

var tabDatabase = {};

var originUrls = ["http://www.amazon.in",
    "https://www.amazon.in",
    "https://www.flipkart.com"
];

chrome.tabs.onActivated.addListener(function (activeInfo) {
    chrome.tabs.get(activeInfo.tabId, function (tab) {
        console.log("chrome.tabs.onActivated    ---- SendBodyTagString   ---  Page Status : ", tab.status);
        getBodyTagSourceString(tab);
    });
});

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    if (changeInfo.status == 'complete') {
        console.log("chrome.tabs.onUpdated    ---- SendBodyTagString   ---  Page Status : ", tab.status);
        getBodyTagSourceString(tab);
    }
});

function getBodyTagSourceString(tab) {
    chrome.tabs.sendMessage(tab.id, { action: "SendBodyTagString" }, function (response) {
        if (response && response.sourceString && tab.status === "complete") {
            afterGettingSource(response.sourceString, tab);
        }
        else {
            console.log("SendBodyTagString returned UNDEFINED");
            disableExtension(tab.id)
        }
    });
}

function afterGettingSource(data, tab) {
    let isShoppingSite = false;
    let originUrl = tab.url.match(/^[\w-]+:\/{2,}\[?[\w\.:-]+\]?(?::[0-9]*)?/)[0];
    originUrls.forEach((value) => {
        if (value.startsWith(originUrl)) {
            isShoppingSite = true;
        }
    });
    if (isShoppingSite) {

        // data = data.split("<body")[1].split(">").slice(1).join(">").split("</body>")[0];
        let price = 0;
        data = data.replace(/<script[^>]+?\/>|<script(.|\s)*?\/script>/gi, '').trim();
        data = $.parseHTML(data);
        if (originUrl.indexOf("amazon") !== -1) {
            amazonSource(data, tab.id);
        }
        else if (originUrl.indexOf("flipkart") !== -1) {
            flipkartSource(data, tab.id);
            console.log("FLIPKART SITE");
        }
    } else {
        disableExtension(tab.id);
    }
}

function flipkartSource(data, tabId) {

    let productName = $(data).find("._3eAQiD").text().trim();
    let flipkartPrice = $(data).find("._1vC4OE._37U4_g").text().trim();

    price = Number(flipkartPrice.replace(/[^0-9\.]+/g, ""));

    console.log("flipkartPrice  " + flipkartPrice);
    console.log("price  " + price);
    if (productName && price) {
        enableExtension(productName, price, tabId);
    }
    else {
        disableExtension(tabId);
    }
}

function amazonSource(data, tabId) {

    let productName = $(data).find("#productTitle").text().trim();
    let amazonSalePrice = $(data).find("#priceblock_saleprice").text().trim();
    let amazonPrice = $(data).find("#priceblock_ourprice").text().trim();
    let amazonDealPrice = $(data).find("#priceblock_dealprice").text().trim();

    amazonPrice = Number(amazonPrice.replace(/[^0-9\.]+/g, ""));
    amazonSalePrice = Number(amazonSalePrice.replace(/[^0-9\.]+/g, ""));
    amazonDealPrice = Number(amazonDealPrice.replace(/[^0-9\.]+/g, ""));

    let prices = [];

    if (amazonSalePrice) { prices.push(amazonSalePrice) }
    if (amazonPrice) { prices.push(amazonPrice) }
    if (amazonDealPrice) { prices.push(amazonDealPrice) }

    price = Math.min.apply(Math, prices);
    if (price == Infinity) {
        price = 0;
    }
    console.log("price  " + price);
    if (productName && price) {
        enableExtension(productName, price, tabId);
    }
    else {
        disableExtension(tabId);
    }
}

function enableExtension(productName, price, tabId) {
    if (tabDatabase[tabId] && tabDatabase[tabId].productName && tabDatabase[tabId].price) {
        if (tabDatabase[tabId].productName === productName && tabDatabase[tabId].price === price) {
            console.log("Values are already stored");
        }
        else {
            tabDatabase[tabId].productName = productName;
            tabDatabase[tabId].price = price;
            console.log("Values are UPDATED");
            onValuesUpdate(productName, price, tabId);
        }
    }
    else {
        tabDatabase[tabId] = {};
        tabDatabase[tabId].productName = productName;
        tabDatabase[tabId].price = price;
        console.log("Values are ADDED");
        onValuesUpdate(productName, price, tabId);
    }

    chrome.browserAction.setIcon({
        path: "icon16.png",
        tabId: tabId
    });
    chrome.browserAction.setBadgeText({ text: "1", tabId: tabId });
    badgeTextData[tabId] = { badgeText: "1" };
}

function onValuesUpdate(productName, price, tabId) {
    var root = 'http://saileshwedseshwari.in/php/sendmail.php';
    $.ajax({
        url: root, success: function (data) {
            console.log("Product : " + productName + "     Price: " + price + "              Save : " + data);
        }
    });
}
function disableExtension(tabId) {
    chrome.browserAction.setBadgeText({ text: "", tabId: tabId });
    chrome.browserAction.setIcon({
        path: "disabledIcon16.png",
        tabId: tabId
    });
    badgeTextData[tabId] = { badgeText: "" };
}

// function getCurrentTab(callback) {
//     // Query filter to be passed to chrome.tabs.query - see
//     // https://developer.chrome.com/extensions/tabs#method-query
//     var queryInfo = {
//         active: true,
//         currentWindow: true
//     };

//     chrome.tabs.query(queryInfo, function (tabs) {
//         var tab = tabs[0];

//         callback(tab);
//     });
// }